import java.util.ArrayList;
import java.util.List;

abstract public class Gerente{
    //private boolean contaExiste;
    private Conta conta;
    private CartaoDeCredito cartao;

    public Gerente(){
    }

    // Getter
    public double getReal(){
        return conta.getReal();
    }
    public double getDolar(){
        return conta.getDolar();
    }
    public double getPeso(){
        return conta.getPeso();
    }
    public double getEuro(){
        return conta.getEuro();
    }
    public double getCaixaReal(){
        return conta.getCaixaReal();
    }
    public double getCaixaDolar(){
        return conta.getCaixaDolar();
    }
    public double getCaixaPeso(){
        return conta.getCaixaPeso();
    }
    public double getCaixaEuro(){
        return conta.getCaixaEuro();
    }
    public double getDividaCartao(){
        return cartao.getDivida();
    }

    // Excepitions
    public void verificaConta() throws MensagemException{
        if(conta.getContaExiste()==false){
            throw new MensagemException("Conta não existe.");
        }
    }
    private void verificaSenha(String senha) throws MensagemException{
        if(conta.getSenha()!=senha){
            throw new MensagemException("Senha incorreta.");
        }
    }
    public void verificaEmprestimoRealizado() throws MensagemException{
        if(conta.getEmprestimoRealizado() == true){
            throw new MensagemException("O cliente já possui um empréstimo.");
        }
    }
    public void verificaLimite(double valor1, double valor2) throws MensagemException{
        if(valor1>valor2){
            throw new MensagemException("O valor ultrapassa o limite do cliente.");
        }
    }
    public void verificaCaixa(double valor1, double valor2) throws MensagemException{
        if(valor1>valor2){
            throw new MensagemException("O caixa não possui o valor solicitado guardado.");
        }
    }
    public void verificaEmprestimoPago() throws MensagemException{
        if(conta.getEmprestimoRealizado() == false){
            throw new MensagemException("O cliente não possui um empréstimo.");
        }
    }
    public void verificaSaques() throws MensagemException{
        if(conta.getSaquesRealizados()>conta.verificaSaques()){
            throw new MensagemException("Não é possível saquar mais. Entre em contato com o banco para solicitar mais saques.");
        }
    }
    public void verificaSolicitarSaques() throws MensagemException{
        if(conta.getSaquesRealizados()<conta.verificaSaques()){
            throw new MensagemException("Não é possível solicitar saques.");
        }
    }
    public void verificaMoedas(String moeda1, String moeda2) throws MensagemException{
        if(moeda1 == moeda2){
            throw new MensagemException("Moedas iguais");
        }
    }
    public void verificaCartao() throws MensagemException{
        if(cartao.getCartaoExiste()==false){
            throw new MensagemException("O cliente não possui o cartão do banco.");
        }
    }
    public void verificaDivida(double valor1, double valor2) throws MensagemException{
        if(valor1>valor2){
            throw new MensagemException("Uso do cartão não foi aceito. Verifique seu limite!");
        }
    }
    public void verificaDividaCartao() throws MensagemException{
        if(cartao.getDividaExiste()==false){
            throw new MensagemException("Não precisa pagar o cartão");
        }
    }

    // Funçoes auxiliares
    public void verificaTipoDaMoeda(String tipoDaMoeda, double valor, String operacao){
        if(tipoDaMoeda == "real"){
            conta.setSimbolo("R$");
            if(operacao == "depósito"){
                conta.setReal(conta.getReal()+valor);
                conta.setCaixaReal(conta.getCaixaReal()+valor);
            }
            else{
                conta.setReal(conta.getReal()-valor);
                conta.setCaixaReal(conta.getCaixaReal()-valor);
            }
        }
        else if(tipoDaMoeda == "dólar"){
            conta.setSimbolo("$");
            if(operacao == "depósito"){
                conta.setDolar(conta.getDolar()+valor);
                conta.setCaixaDolar(conta.getCaixaDolar()+valor);  
            }
            else{
                conta.setDolar(conta.getDolar()-valor);
                conta.setCaixaDolar(conta.getCaixaDolar()-valor);
            }
        }
        else if(tipoDaMoeda == "peso"){
            conta.setSimbolo("P$");
            if(operacao == "depósito"){
                conta.setPeso(conta.getPeso()+valor);
                conta.setCaixaPeso(conta.getCaixaPeso()+valor);  
            }
            else{
                conta.setPeso(conta.getPeso()-valor);
                conta.setCaixaPeso(conta.getCaixaPeso()-valor);
            }
        }
        else{
            conta.setSimbolo("€");
            if(operacao == "depósito"){
                conta.setEuro(conta.getEuro()+valor);
                conta.setCaixaEuro(conta.getCaixaEuro()+valor);  
            }
            else{
                conta.setEuro(conta.getEuro()-valor);
                conta.setCaixaEuro(conta.getCaixaEuro()-valor);
            }
        }
    }

    // Função para criar a conta
    public void criaConta(String nomeDoDono, String senha, String tipoDaConta){
        List<String> extrato = new ArrayList<>();
        this.conta = new Conta(nomeDoDono, senha, tipoDaConta, 0, 0, 0, 0, extrato);
        conta.addExtrato("Conta criada");
    }
    
    // Função para o depósito
    public String deposito(double valor, String tipoDaMoeda, String senha){
        try{
            verificaConta(); verificaSenha(senha);
            verificaTipoDaMoeda(tipoDaMoeda, valor, "depósito");
            conta.addExtrato("Depósito de " + (valor) + " " + conta.getSimbolo());
            return Double.toString(valor);
        }
        catch(MensagemException e){
            return e.getMessage();
        }
    }

    // Função para o extrato
    public void extrato(String senha){
        try{
            verificaConta(); verificaSenha(senha);
            List<String> operacoes = conta.getExtrato();
            for(int i=0;i<operacoes.size();i++){
                System.out.println(operacoes.get(i));
            }
        }
        catch(MensagemException e){
            System.out.println(e.getMessage());
        }
    }

    // Função para o empréstimo
    public String realizarEmprestimo(double valor, String senha){
        try{
            verificaConta(); verificaSenha(senha); verificaEmprestimoRealizado(); verificaLimite(valor, conta.verificaTipoDaConta("limiteEmprestimo")); verificaCaixa(valor, conta.getCaixaReal());
            conta.setEmprestimoRealizado(true);
            conta.setEmprestimo(valor*conta.verificaTipoDaConta("multiplicador"));
            conta.setReal(conta.getReal()+valor);
            conta.setCaixaReal(conta.getCaixaReal()-valor);
            conta.addExtrato("Empréstimo de " + valor + " R$");
            return Double.toString(valor);
        }
        catch(MensagemException e){
            return e.getMessage();
        }
    }
    public String verificaLimiteDeEmprestimo(String senha){
        try{
            verificaConta(); verificaSenha(senha);
            return Double.toString(conta.verificaTipoDaConta("limiteEmprestimo"));
        }
        catch(MensagemException e){
            return e.getMessage();
        }
    }
    public String pagarEmprestimo(double valor, String senha){
        try{
            verificaConta(); verificaSenha(senha); verificaEmprestimoPago();
            conta.addExtrato("Pagamento do empréstimo em " + valor + " R$");
            if(valor<conta.getEmprestimo()){
                conta.setEmprestimo(conta.getEmprestimo()-valor);
                return Double.toString(valor);
            }
            else if(valor==conta.getEmprestimo()){
                conta.setEmprestimo(0);
                conta.setEmprestimoRealizado(false);
                return Double.toString(valor);
            }
            else{
                conta.setEmprestimoRealizado(false);
                deposito(valor-conta.getEmprestimo(), "real", senha);
                conta.addExtrato("Depósito de " + (valor-conta.getEmprestimo()) + " R$");
                conta.setEmprestimo(0);
                return Double.toString(valor);
            }
        }
        catch(MensagemException e){
            return e.getMessage();
        }
    }
    public String verificaEmprestimo(String senha){
        try{
            verificaConta(); verificaSenha(senha);
            return Double.toString(conta.getEmprestimo());
        }
        catch(MensagemException e){
            return e.getMessage();
        }
    }

    // Saque
    public String saque(double valor, String tipoDaMoeda, String senha){
        double[] info = conta.verificaTipoDaMoeda(tipoDaMoeda, conta.getTipoDaConta());
        try{
            verificaConta(); verificaSenha(senha); verificaLimite(valor, info[1]+info[2]); verificaSaques(); verificaCaixa(valor, info[3]);
            conta.setSaquesRealizados(conta.getSaquesRealizados()+1);
            verificaTipoDaMoeda(tipoDaMoeda, valor+info[2], "saque");
            conta.addExtrato("Saque de " + valor + " " + conta.getSimbolo());
            return Double.toString(valor);
        }
        catch(MensagemException e){
            return e.getMessage();
        }
    }
    public String solicitaSaque(String senha){
        try{
            verificaConta(); verificaSenha(senha); verificaSolicitarSaques();
            conta.setSaquesRealizados(0);
            return Double.toString(conta.verificaSaques());
        }
        catch(MensagemException e){
            return e.getMessage();
        }
    }

    // Câmbio
    public void verificaCambio(String tipoDaMoeda1, String tipoDaMoeda2, double valor){
        if(tipoDaMoeda1 == "real"){
            conta.setSimbolo("R$");
            conta.setReal(conta.getReal()-valor);
            if(tipoDaMoeda2 == "dólar"){
                conta.setDolar(conta.getDolar()+valor/6);
            }
            else if(tipoDaMoeda2 == "peso"){
                conta.setPeso(conta.getPeso()+valor*3);
            }
            else{
                conta.setEuro(conta.getEuro()+valor/10);
            }
        }
        else if(tipoDaMoeda1 == "dólar"){
            conta.setSimbolo("$");
            conta.setDolar(conta.getDolar()-valor);
            if(tipoDaMoeda2 == "real"){
                conta.setReal(conta.getReal()+valor*6);
            }
            else if(tipoDaMoeda2 == "peso"){
                conta.setPeso(conta.getPeso()+valor*18);
            }
            else{
                conta.setEuro(conta.getEuro()+valor/2);
            }
        }
        else if(tipoDaMoeda1 == "peso"){
            conta.setSimbolo("P$");
            conta.setPeso(conta.getPeso()-valor);
            if(tipoDaMoeda2 == "real"){
                conta.setReal(conta.getReal()+valor/3);
            }
            else if(tipoDaMoeda2 == "dólar"){
                conta.setDolar(conta.getDolar()+valor/18);
            }
            else{
                conta.setEuro(conta.getEuro()+valor/30);
            }
        }
        else{
            conta.setSimbolo("€");
            conta.setEuro(conta.getEuro()-valor);
            if(tipoDaMoeda2 == "real"){
                conta.setReal(conta.getReal()+valor*10);
            }
            else if(tipoDaMoeda2 == "dólar"){
                conta.setDolar(conta.getDolar()+valor*2);
            }
            else{
                conta.setPeso(conta.getPeso()+valor*30);
            }
        }
    }
    public void cambio(String tipoDaMoeda1, String tipoDaMoeda2, double valor, String senha){
        try{
            verificaConta(); verificaSenha(senha); verificaMoedas(tipoDaMoeda1, tipoDaMoeda2);
            verificaCambio(tipoDaMoeda1, tipoDaMoeda2, valor);
            conta.addExtrato("Conversão de " + valor + " " + tipoDaMoeda1 + " em " + tipoDaMoeda2);
        }
        catch(MensagemException e){
            System.out.println(e.getMessage());
        }
    }

    // Cartão de Crédito
    public String criaCartao(String senha){
        try{
            verificaConta(); verificaSenha(senha);
            this.cartao = new CartaoDeCredito(conta.verificaTipoDaConta("cria cartao"));
            conta.addExtrato("Cartão criado");
            return ("Cartão criado\n");
        }
        catch(MensagemException e){
            return e.getMessage();
        }
    }
    public void usarCartao(String senha, double valor){
        try{
            verificaConta(); verificaSenha(senha); verificaCartao(); verificaLimite(valor, cartao.getLimiteCartao()); verificaDivida(cartao.getDivida()+valor,cartao.getLimiteCartao());
            conta.addExtrato("Pagamento de " + valor + " R$ com o cartão");
            cartao.setDinheiroCartao(cartao.getDinheiroCartao()-valor);
            cartao.setDivida(cartao.getDivida()+valor);
        }
        catch(MensagemException e){
            System.out.println(e.getMessage());
        }
    }
    public void pagarCartao(String senha, double valor){
        try{
            verificaConta(); verificaSenha(senha); verificaCartao(); verificaDividaCartao();
            conta.addExtrato("Pagamento do cartão.");
            cartao.setDinheiroCartao(cartao.getLimiteCartao());
            cartao.setDivida(0);
        }
        catch(MensagemException e){
            System.out.println(e.getMessage());
        } 
    }
    public String verificaValorCartao(String senha){
        try{
            verificaConta(); verificaSenha(senha);
            return Double.toString(cartao.getDinheiroCartao());
        }
        catch(MensagemException e){
            return e.getMessage();
        } 
    }
    public String verificaDividaCartaoCredito(String senha){
        try{
            verificaConta(); verificaSenha(senha);
            return Double.toString(cartao.getDivida());
        }
        catch(MensagemException e){
            return e.getMessage();
        } 
    }
}