abstract public class Moeda {
    private double real, peso, euro, dolar;
    private double tarifa, limite;
    private double caixaReal, caixaPeso, caixaEuro, caixaDolar = 1000000;
    private String simbolo;

    // Getters e Setters
    public void setReal(double valor){
        this.real = valor;
    }
    public double getReal(){
        return this.real;
    }
    public void setDolar(double valor){
        this.dolar = valor;
    }
    public double getDolar(){
        return this.dolar;
    }
    public void setPeso(double valor){
        this.peso = valor;
    }
    public double getPeso(){
        return this.peso;
    }
    public void setEuro(double valor){
        this.euro = valor;
    }
    public double getEuro(){
        return this.euro;
    }
    public String getSimbolo(){
        return this.simbolo;
    }
    public void setSimbolo(String simbolo){
        this.simbolo = simbolo;
    }
    public void setCaixaReal(double valor){
        this.caixaReal = valor;
    }
    public double getCaixaReal(){
        return this.caixaReal;
    }
    public void setCaixaDolar(double valor){
        this.caixaDolar = valor;
    }
    public double getCaixaDolar(){
        return this.caixaDolar;
    }
    public void setCaixaPeso(double valor){
        this.caixaPeso = valor;
    }
    public double getCaixaPeso(){
        return this.caixaPeso;
    }
    public void setCaixaEuro(double valor){
        this.caixaEuro = valor;
    }
    public double getCaixaEuro(){
        return this.caixaEuro;
    }

    // Função auxiliar
    public double verificaMoeda(String tipoDaMoeda){
        if(tipoDaMoeda == "real"){
            return this.real;
        }
        else if(tipoDaMoeda == "dólar"){
            
            return this.dolar;
        }
        else if(tipoDaMoeda == "peso"){
            
            return this.peso;
        }
        else{
            
            return this.euro;
        }
    }
    public double[] verificaTipoDaMoeda(String tipoDaMoeda, String tipoDaConta){
        if(tipoDaMoeda == "real"){
            this.simbolo = "R$";
            if(tipoDaConta == "Conta Corrente"){
                this.tarifa = 2.55;
                this.limite = 2000;
            }
            else if(tipoDaConta == "Conta Poupança"){
                this.tarifa = 6.6;
                this.limite = 1500;
            }
            else{
                this.tarifa = 0;
                this.limite = 500;
            }
            return new double[]{real, limite, tarifa, caixaReal};
        }
        else if(tipoDaMoeda == "dólar"){
            this.simbolo = "$";
            if(tipoDaConta == "Conta Corrente"){
                this.tarifa = 12;
                this.limite = 400;
            }
            else if(tipoDaConta == "Conta Poupança"){
                this.tarifa = 32.1;
                this.limite = 300;
            }
            else{
                this.tarifa = 0;
                this.limite = 100;
            }
            return new double[]{dolar, limite, tarifa, caixaDolar};
        }
        else if(tipoDaMoeda == "peso"){
            this.simbolo = "P$";
            if(tipoDaConta == "Conta Corrente"){
                this.tarifa = 1.3;
                this.limite = 3000;
            }
            else if(tipoDaConta == "Conta Poupança"){
                this.tarifa = 3.3;
                this.limite = 2000;
            }
            else{
                this.tarifa = 0;
                this.limite = 700;
            }
            return new double[]{peso, limite, tarifa, caixaPeso};
        }
        else{
            this.simbolo = "€";
            if(tipoDaConta == "Conta Corrente"){
                this.tarifa = 25.5;
                this.limite = 140;
            }
            else if(tipoDaConta == "Conta Poupança"){
                this.tarifa = 66.6;
                this.limite = 200;
            }
            else{
                this.tarifa = 0;
                this.limite = 50;
            }
            return new double[]{euro, limite, tarifa, caixaEuro};
        }
    }  
}
