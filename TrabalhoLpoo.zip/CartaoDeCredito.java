public class CartaoDeCredito {
    private double dinheiroCartao;
    private double divida;
    private double limiteCartao;
    private boolean cartaoExiste, dividaExiste = false;

    public CartaoDeCredito(double limiteCartao) {
        this.dinheiroCartao = limiteCartao;
        this.limiteCartao = limiteCartao;
        this.cartaoExiste = true;
        this.divida = 0;
        this.dividaExiste = false;
    }

    // Getters e Setters
    public double getDinheiroCartao() {
        return dinheiroCartao;
    }
    public void setDinheiroCartao(double dinheiroCartao) {
        this.dinheiroCartao = dinheiroCartao;
    }
    public double getDivida() {
        return divida;
    }
    public void setDivida(double divida) {
        this.divida = divida;
    }
    public double getLimiteCartao() {
        return limiteCartao;
    }
    public void setLimiteCartao(double limiteCartao) {
        this.limiteCartao = limiteCartao;
    }
    public boolean getCartaoExiste() {
        return this.cartaoExiste;
    }
    public boolean getDividaExiste() {
        return this.dividaExiste;
    }
    public void setDividaExiste(boolean dividaExiste) {
        this.dividaExiste = dividaExiste;
    } 
}