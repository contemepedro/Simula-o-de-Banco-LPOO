public class MensagemException extends Exception{

    public MensagemException (String msg) {
        super(msg);
    }
}
