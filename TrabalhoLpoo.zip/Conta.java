import java.util.List;

public class Conta extends Moeda{
    private String nomeDoDono, senha, tipoDaConta;
    private boolean emprestimoRealizado, contaExiste;
    private double emprestimo;
    private int saquesRealizados;
    private List<String> extrato;

    public Conta(String nomeDoDono, String senha, String tipoDaConta, double valorReal, double valorDolar, double valorPeso, double valorEuro, List<String> extrato){
        super.setReal(valorReal);
        super.setDolar(valorDolar);
        super.setEuro(valorEuro);
        super.setPeso(valorPeso);
        this.nomeDoDono = nomeDoDono;
        this.senha = senha;
        this.tipoDaConta = tipoDaConta;
        this.extrato = extrato;
        this.emprestimoRealizado = false;
        this.emprestimo = 0;
        this.saquesRealizados = 0;
        this.contaExiste = true;
    }

    // Getters e Setters
    public void setNomeDoDono(String nomeDoDono){
        this.nomeDoDono = nomeDoDono;
    }
    public String getNomeDoDono(){
        return this.nomeDoDono;
    }
    public void setSenha(String senha){
        this.senha = senha;
    }
    public String getSenha(){
        return this.senha;
    }
    public void setTipoDaConta(String tipoDaConta){
        this.tipoDaConta = tipoDaConta;
    }
    public String getTipoDaConta(){
        return this.tipoDaConta;
    }
    public List<String> getExtrato(){
        return this.extrato;
    }
    public void setEmprestimoRealizado(boolean condicao){
        this.emprestimoRealizado = condicao;
    }
    public boolean getEmprestimoRealizado(){
        return this.emprestimoRealizado;
    }
    public void setEmprestimo(double valor){
        this.emprestimo = valor;
    }
    public double getEmprestimo(){
        return this.emprestimo;
    }
    public void setSaquesRealizados(int valor){
        this.saquesRealizados = valor;
    }
    public int getSaquesRealizados(){
        return this.saquesRealizados;
    }
    public boolean getContaExiste(){
        return  this.contaExiste;
    }
    
    // Funções auxiliares
    public void addExtrato(String operacao){
        extrato.add(operacao);
    }
    public void clearExtrato(){
        extrato.clear();
    }
    public double verificaTipoDaConta(String operacao){
        if(this.tipoDaConta == "Conta Corrente"){
            if(operacao == "multiplicador"){
                return 1.5;
            }
            else if(operacao == "cria cartao"){
                return 6000;
            }
            return (super.getReal()*20);
        }
        else if(this.tipoDaConta == "Conta Estudante"){
            if(operacao == "multiplicador"){
                return 1.2;
            }
            else if(operacao == "cria cartao"){
                return 800;
            }
            return (super.getReal()*5);
        }
        else{
            if(operacao == "multiplicador"){
                return 1.7;
            }
            else if(operacao == "cria cartao"){
                return 2500;
            }
            return (super.getReal()*10);
        }
    }
    public int verificaSaques(){
        if(this.tipoDaConta == "Conta Corrente"){
            return 5;
        }
        else if(this.tipoDaConta == "Conta Estudante"){
            return 2;
        }
        else{
            return 3;
        }
    }
}
