public class Cliente extends Gerente{
    private String nome;
    private double carteiraReal, carteiraDolar, carteiraPeso, carteiraEuro;

    public Cliente(String nome, double carteiraReal, double carteiraDolar, double carteiraPeso, double carteiraEuro){
        this.nome = nome;
        this.carteiraReal = carteiraReal;
        this.carteiraDolar = carteiraDolar;
        this.carteiraPeso = carteiraPeso;
        this.carteiraEuro = carteiraEuro;
    }

    // Getters e Setters
    public void setNome(String nome){
        this.nome = nome;
    }
    public String getNome(){
        return this.nome;
    }
    public void addCarteiraReal(double carteira){
        this.carteiraReal += carteira;
    }
    public double getCarteiraReal(){
        return this.carteiraReal;   
    }
    public void addCarteiraDolar(double carteira){
        this.carteiraDolar += carteira;
    }
    public double getCarteiraDolar(){
        return this.carteiraDolar;   
    }
    public void addCarteiraPeso(double carteira){
        this.carteiraPeso += carteira;
    }
    public double getCarteiraPeso(){
        return this.carteiraPeso;   
    }
    public void addCarteiraEuro(double carteira){
        this.carteiraEuro += carteira;
    }
    public double getCarteiraEuro(){
        return this.carteiraEuro;   
    }

    // Excepitions
    public void comparaValor(double valor1, double valor2) throws MensagemException{
        if(valor1>valor2){
            throw new MensagemException("O cliente não tem dinheiro suficiente para depositar");
        }
    }
    public void comparaValorCartao(double valor1, double valor2) throws MensagemException{
        if(valor1>valor2){
            throw new MensagemException("O cliente não tem dinheiro suficiente para pagar o cartao");
        }
    }

    // Funções auxiliares
    public void verificaMoeda(String tipoDaMoeda, double valor, String operacao){
        if(tipoDaMoeda == "real"){
            if(operacao == "depósito"){
               this.carteiraReal -= valor; 
            }
            else{
                this.carteiraReal += valor;
            }
        }
        else if(tipoDaMoeda == "dólar"){
            if(operacao == "depósito"){
                this.carteiraDolar -= valor; 
             }
             else{
                this.carteiraDolar += valor;
             }
        }
        else if(tipoDaMoeda == "peso"){
            if(operacao == "depósito"){
                this.carteiraPeso -= valor; 
             }
             else{
                 this.carteiraPeso += valor;
             }
        }
        else{
            if(operacao == "depósito"){
                this.carteiraEuro -= valor; 
             }
             else{
                 this.carteiraEuro += valor;
             }
        }
    }
    public double verificaTipoDaMoeda(String tipoDaMoeda){
        if(tipoDaMoeda == "real"){
            return this.carteiraReal;
        }
        else if(tipoDaMoeda == "dólar"){
            return this.carteiraDolar;
        }
        else if(tipoDaMoeda == "peso"){
            return this.carteiraPeso;
        }
        else{
            return this.carteiraEuro;
        }
    }

    // Função de depósito
    public String depositar(double valor, String tipoDaMoeda, String senha){
        String resultado;
        try{
            comparaValor(valor, verificaTipoDaMoeda(tipoDaMoeda));
            resultado = super.deposito(valor, tipoDaMoeda, senha);
            verificaMoeda(tipoDaMoeda, Double.parseDouble(resultado), "depósito");
            return resultado;
        }
        catch(MensagemException e){
            return e.getMessage();
        }
    }

    public String pagarEmprestimo(double valor, String senha){
        String resultado = super.pagarEmprestimo(valor, senha);
        this.carteiraReal -= Double.parseDouble(resultado);
        return resultado;
    }

    // Função de saque
    public String saque(double valor, String tipoDaMoeda, String senha){
        String resultado = super.saque(valor, tipoDaMoeda, senha);
        if(Double.parseDouble(resultado)>0){
            verificaMoeda(tipoDaMoeda, Double.parseDouble(resultado), "saque");
        }
        return resultado;
    }

    // Função do cartao
    public void pagarCartao(String senha, double valor){
        try{
            comparaValorCartao(valor, this.carteiraReal);
            if(valor==super.getDividaCartao()){
                super.pagarCartao(senha, valor);
                this.carteiraReal -= valor;
            }
            else if(valor>super.getDividaCartao()){
                super.pagarCartao(senha, super.getDividaCartao());
                this.carteiraReal -= super.getDividaCartao();
            }
            else{
                System.out.println("O pagamento do cartão deve ser pago de uma vez só");
            }
        }
        catch(MensagemException e){
            System.out.println(e.getMessage());
        }
    }
}