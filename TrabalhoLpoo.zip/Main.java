import java.util.Scanner;

public class Main {
    static Scanner leia = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        System.out.println("--- CAPIVARA BANK ---");
        System.out.println("Criando Conta cliente");
        Cliente cliente = CriaCliente(); // cria cliente, sua conta e seu cartão
        while(cliente == null){
            cliente = CriaCliente();// repete o processo caso o anterior dê errado
        }
        
        int opt = 0;
        while(opt != 8){
            System.out.println("--- MENU ---");
            System.out.println("1 - Empréstimo");
            System.out.println("2 - Saque");
            System.out.println("3 - Depósito");
            System.out.println("4 - Checar Balanço da Conta");
            System.out.println("5 - Câmbio");
            System.out.println("6 - Extrato");
            System.out.println("7 - Meu Cartão");
            System.out.println("8 - Sair");

            opt = leia.nextInt();
            leia.nextLine();
            String senha, moeda;
            Double valor;
            int opc;
            switch(opt){
                case 1: // empréstimo
                    System.out.println("Digite sua senha:");
                    senha = leia.nextLine();
                    System.out.println("Você ainda pode fazer " + cliente.verificaLimiteDeEmprestimo(senha) + " empréstimos");
                    System.out.println("--- EMPRÉSTIMO ---");
                    System.out.println("1 - Fazer Empréstimo");
                    System.out.println("2 - Pagar Empréstimo");
                    System.out.println("3 - voltar");
                    opc = leia.nextInt();
                    leia.nextLine();
                    switch(opc){
                        case 1://fazer empréstimo
                            System.out.println("Digite o valor a emprestar:");
                            valor = leia.nextDouble();
                            cliente.realizarEmprestimo(valor, senha);
                            break;
                        
                        case 2:// pagar empréstimo
                            System.out.println("Digite o valor a pagar:");
                            valor = leia.nextDouble();
                            cliente.pagarEmprestimo(valor, senha);
                            break;

                        case 3://volta ao menu principal
                            break;
                        
                        default:
                            System.out.println("Comando incorreto, voltando ao menu");
                    }
                    break;
                
                case 2: // faz saque a cliente
                    System.out.println("Digite sua senha:");
                    senha = leia.nextLine();
                    moeda = TipoMoeda();
                    System.out.println("Digite o valor a sacar:");
                    cliente.saque(leia.nextDouble(), moeda, senha);
                    break;
                
                case 3: // faz depósito a cliente
                    System.out.println("Digite sua senha:");
                    senha = leia.nextLine();
                    moeda = TipoMoeda();
                    System.out.println("Digite o valor a depositar:");
                    cliente.deposito(leia.nextDouble(), moeda, senha);
                    break;
                
                case 4: // checa balanço da conta cliente
                    System.out.println("--- BALANÇO DA CONTA ---");
                    System.out.println("Valor na carteira: ");
                    System.out.println("Reais: " + cliente.getCarteiraReal());
                    System.out.println("Dólares: " + cliente.getCarteiraDolar());
                    System.out.println("Pesos: " + cliente.getCarteiraPeso());
                    System.out.println("Euros: " + cliente.getCarteiraEuro());
                    System.out.println("--------------------------------");
                    System.out.println("Valor na conta: ");
                    System.out.println("Reais: " + cliente.getReal());
                    System.out.println("Dólares: " + cliente.getDolar());
                    System.out.println("Pesos: " + cliente.getPeso());
                    System.out.println("Euros: " + cliente.getEuro());
                    System.out.println("--------------------------------");
                    break;
                
                case 5: //cambio
                    System.out.println("Digite sua senha:");
                    senha = leia.nextLine();
                    String moeda1, moeda2;
                    System.out.println("moeda de troca");
                    moeda1 = TipoMoeda();
                    System.out.println("Digite o valor a trocar:");
                    valor = leia.nextDouble();
                    System.out.println("moeda que você receberá");
                    moeda2 = TipoMoeda();
                    cliente.cambio(moeda1, moeda2, valor, senha);

                case 6:// extrato
                    System.out.println("Digite sua senha:");
                    senha = leia.nextLine();
                    System.out.println("--- EXTRATO ---");
                    cliente.extrato(senha);

                case 7: // opções do cartão
                    System.out.println("Digite sua senha:");
                    senha = leia.nextLine();
                    System.out.println("Quantia no cartão: " + cliente.verificaValorCartao(senha));
                    System.out.println("--- CARTÃO ---");
                    System.out.println("1 - Usar Cartão");
                    System.out.println("2 - Pagar Cartão");
                    System.out.println("3 - voltar");
                    
                    opc = leia.nextInt();
                    leia.nextLine();
                    switch(opc){
                        case 1:
                            System.out.println("Digite o valor:");
                            valor = leia.nextDouble();
                            System.out.println("Usar Cartão");
                            cliente.usarCartao(senha, valor);
                            break;
                    
                        case 2:
                            System.out.println("Digite o valor:");
                            valor = leia.nextDouble();
                            System.out.println("Pagar Cartão");
                            cliente.pagarCartao(senha, valor);
                            break;
                        
                        case 3:
                            break;
                        
                        default:
                            System.out.println("Comando incorreto. Voltando ao menu principal");
                    }
                    break;

                case 8: // sai do programa
                    System.out.println("Tchau!");
                    break;
                
                default:
                    System.out.println("Comando incorreto. Voltando ao menu principal");
            }
        }
    }

    public static Cliente CriaCliente(){
        System.out.println("Criação de conta - Cliente");
        System.out.println("Digite seu nome:");
        String nome = leia.nextLine();
        System.out.println("Digite sua senha:");
        String senha = leia.nextLine();
        System.out.println("Digite a quantia de Reais na sua conta:");
        int carteiraReal = leia.nextInt();
        leia.nextLine();
        System.out.println("Digite a quantia de Dólares na sua conta:");
        int carteiraDolar = leia.nextInt();
        leia.nextLine();
        System.out.println("Digite a quantia de Euros na sua conta:");
        int carteiraEuro = leia.nextInt();
        leia.nextLine();
        System.out.println("Digite a quantia de Pesos na sua conta:");
        int carteiraPeso = leia.nextInt();
        leia.nextLine();
        System.out.println("selecione o tipo de conta:");
        System.out.println("1 - Corrente");
        System.out.println("2 - Poupança");
        System.out.println("3 - Estudante");
        int opt = leia.nextInt();
        leia.nextLine();
        String conta;
        switch(opt){
            case 1:
                System.out.println("Conta Corrente");
                conta = "Conta Corrente";
                break;
            case 2:
                System.out.println("Conta Poupança");
                conta = "Conta Poupança";
                break;
            case 3:
                System.out.println("Conta Estudante");
                conta = "Conta Estudante";
                break;
            default:
                System.out.println("Comando incorreto. Voltando ao menu principal");
                return null;
        }
        
        Cliente cliente = new Cliente(nome, carteiraReal, carteiraDolar, carteiraPeso, carteiraEuro);
        cliente.criaConta(nome, senha, conta);
        cliente.criaCartao(senha);
        System.out.println("Cartão criado com sucesso");
        return cliente;
    }

    public static String TipoMoeda(){
        System.out.println("selecione o tipo de moeda:");
        System.out.println("1 - Real");
        System.out.println("2 - Dólar");
        System.out.println("3 - Euro");
        System.out.println("4 - Peso");
        int opc = leia.nextInt();
        leia.nextLine();
        switch(opc){
            case 1:
                System.out.println("real");
                return "real";
            case 2:
                System.out.println("dólar");
                return "dólar";
            case 3:
                System.out.println("euro");
                return "euro";
            case 4:
                System.out.println("peso");
                return "peso";
            default:
                System.out.println("Comando incorreto. Valor padrão: real");
                return "real";
        }
    }
}